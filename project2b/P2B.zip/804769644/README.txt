Did not do the extra credit. 
Our data is in decimal form (exe 97% is .97). 
But when making out plots, we changed the vmin and vmax in the code to multiply them by 100 so work with percentages. 

Took both late days for this project, used none for the 2A. 